
  # Tela de Login Advocacia

  This is a code bundle for Tela de Login Advocacia. The original project is available at https://www.figma.com/design/3VDpWdidvWfzIYPy3wOPOE/Tela-de-Login-Advocacia.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  